const form = document.getElementById("eligibilityForm");
const submitBtn = document.getElementById("submitBtn");
const resultsSection = document.getElementById("resultsSection");
const resultsList = document.getElementById("resultsList");
const resultsSummary = document.getElementById("resultsSummary");

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  submitBtn.disabled = true;
  submitBtn.textContent = "Checking…";
  const formData = new FormData(form);
  const payload = Object.fromEntries(formData.entries());
  payload.disability = formData.has("disability");
  try {
    const response = await fetch("/api/check", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify(payload)
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Unable to check eligibility.");
    renderResults(data);
    resultsSection.classList.remove("hidden");
    resultsSection.scrollIntoView({behavior: "smooth"});
    loadHistory();
  } catch (error) {
    alert(error.message);
  } finally {
    submitBtn.disabled = false;
    submitBtn.innerHTML = 'Check eligibility <span>→</span>';
  }
});

function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, char => ({
    "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;"
  })[char]);
}

function renderResults(data) {
  const matches = data.matches;
  const potential = matches.filter(item => item.status === "Potential match").length;
  const review = matches.filter(item => item.status === "Needs review").length;
  resultsSummary.innerHTML = `
    <div class="summary-card"><strong>${potential}</strong><span>Potential matches</span></div>
    <div class="summary-card"><strong>${review}</strong><span>Need further review</span></div>
    <div class="summary-card"><strong>${matches.length}</strong><span>Total schemes displayed</span></div>`;
  if (!matches.length) {
    resultsList.innerHTML = '<div class="result-card"><h3>No configured matches</h3><p>No scheme in the current demo dataset matched enough conditions. This does not mean you are ineligible for all government schemes.</p></div>';
    return;
  }
  resultsList.innerHTML = matches.map(item => {
    const isMatch = item.status === "Potential match";
    const matched = item.matched_conditions.map(x => `<li>${escapeHtml(x)}</li>`).join("");
    const failed = item.conditions_to_check.map(x => `<li>${escapeHtml(x)}</li>`).join("");
    return `<article class="result-card">
      <div class="result-top"><div><h3>${escapeHtml(item.name)}</h3><p>${escapeHtml(item.provider)} · ${escapeHtml(item.id)}</p></div>
      <span class="status ${isMatch ? "match" : "review"}">${escapeHtml(item.status)}</span></div>
      <p>${escapeHtml(item.description)}</p><p><strong>Benefit:</strong> ${escapeHtml(item.benefit)}</p>
      ${matched ? `<p><strong>Conditions matched</strong></p><ul>${matched}</ul>` : ""}
      ${failed ? `<p><strong>Conditions needing attention</strong></p><ul>${failed}</ul>` : ""}
      <p><strong>Verification:</strong> ${escapeHtml(item.verification_note)}</p>
      <a href="${escapeHtml(item.official_url)}" target="_blank" rel="noopener">Visit official information source ↗</a>
    </article>`;
  }).join("");
}

async function loadHistory() {
  const container = document.getElementById("historyList");
  try {
    const response = await fetch("/api/recent");
    const data = await response.json();
    if (!data.assessments.length) {
      container.innerHTML = '<p class="muted">No assessments yet. Submit the form to create the first record.</p>';
      return;
    }
    container.innerHTML = `<div class="history-row header"><span>Student</span><span>State / Category</span><span>Education</span><span>Potential matches</span></div>` +
      data.assessments.map(item => `<div class="history-row">
        <span>${escapeHtml(item.student_name)} <small>· ${escapeHtml(item.created_at.replace("T"," "))}</small></span>
        <span>${escapeHtml(item.state)} / ${escapeHtml(item.category)}</span>
        <span>${escapeHtml(item.education_level.toUpperCase())}</span>
        <span>${item.match_count}</span>
      </div>`).join("");
  } catch {
    container.innerHTML = '<p class="muted">Assessment history could not be loaded.</p>';
  }
}

document.getElementById("refreshHistory").addEventListener("click", loadHistory);
document.getElementById("printBtn").addEventListener("click", () => window.print());
loadHistory();
