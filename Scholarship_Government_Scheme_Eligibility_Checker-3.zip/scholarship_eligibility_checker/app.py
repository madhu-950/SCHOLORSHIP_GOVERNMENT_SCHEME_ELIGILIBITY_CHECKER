from flask import Flask, render_template, request, jsonify
from database import init_db, save_assessment, get_recent_assessments
from eligibility import evaluate_schemes, load_schemes

app = Flask(__name__)
app.config["JSON_SORT_KEYS"] = False

init_db()
SCHEMES = load_schemes()

@app.get("/")
def index():
    return render_template("index.html", scheme_count=len(SCHEMES))

@app.get("/api/schemes")
def schemes():
    return jsonify({"schemes": SCHEMES})

@app.post("/api/check")
def check_eligibility():
    data = request.get_json(silent=True) or {}
    required = ["name", "age", "state", "category", "annual_income",
                "education_level", "course", "study_year", "marks"]
    missing = [field for field in required if data.get(field) in (None, "")]
    if missing:
        return jsonify({"error": "Please complete all required fields.", "missing": missing}), 400

    try:
        student = {
            "name": str(data["name"]).strip()[:80],
            "age": int(data["age"]),
            "state": str(data["state"]).strip(),
            "category": str(data["category"]).upper(),
            "annual_income": float(data["annual_income"]),
            "education_level": str(data["education_level"]).lower(),
            "course": str(data["course"]).strip()[:100],
            "study_year": int(data["study_year"]),
            "marks": float(data["marks"]),
            "gender": str(data.get("gender", "Not specified")),
            "disability": bool(data.get("disability", False))
        }
    except (TypeError, ValueError):
        return jsonify({"error": "Check that age, income, year and marks are valid numbers."}), 400

    if not (15 <= student["age"] <= 100):
        return jsonify({"error": "Age must be between 15 and 100."}), 400
    if student["annual_income"] < 0 or not (0 <= student["marks"] <= 100):
        return jsonify({"error": "Income cannot be negative and marks must be between 0 and 100."}), 400
    if student["study_year"] < 1 or student["study_year"] > 10:
        return jsonify({"error": "Study year must be between 1 and 10."}), 400

    results = evaluate_schemes(student, SCHEMES)
    assessment_id = save_assessment(student, results)
    return jsonify({
        "assessment_id": assessment_id,
        "student_name": student["name"],
        "matches": results,
        "match_count": len(results),
        "disclaimer": "Preliminary rule-based matches only. This is not an official eligibility decision or scholarship approval."
    })

@app.get("/api/recent")
def recent():
    return jsonify({"assessments": get_recent_assessments()})

if __name__ == "__main__":
    app.run(debug=True)
