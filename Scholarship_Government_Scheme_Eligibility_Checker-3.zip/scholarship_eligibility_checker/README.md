# ScholarCheck — Scholarship & Government Scheme Eligibility Checker

An advanced college-level prototype built with Python (Flask), HTML, CSS, JavaScript and SQLite.

## Features
- Student profile form with validation
- Transparent, configurable rule-based eligibility screening
- Potential-match and needs-review results with reasons
- SQLite assessment history
- Official portal links and print-friendly report
- JSON dataset so scheme rules can be edited without changing Python logic

## Requirements
- Python 3.10 or newer
- pip
- A modern browser

## Setup (Windows)
1. Extract the ZIP file.
2. Open the extracted folder in VS Code.
3. Open Terminal → New Terminal.
4. Create a virtual environment:

   `py -m venv .venv`

5. Activate it:

   PowerShell: `.\.venv\Scripts\Activate.ps1`

   Command Prompt: `.venv\Scripts\activate.bat`

6. Install dependencies:

   `py -m pip install -r requirements.txt`

7. Start the application:

   `py app.py`

8. Open this address in your browser:

   `http://127.0.0.1:5000`

## Setup (Linux / macOS)
```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python app.py
```
Then open `http://127.0.0.1:5000`.

## Example test profile
- Name: Rahul
- Age: 20
- State: Karnataka
- Category: OBC
- Annual family income: 150000
- Education: Undergraduate
- Course: B.Tech AI & DS
- Year: 2
- Marks: 85
- Gender: Male

With the included demonstration data, this profile should show the illustrative OBC rule, the illustrative merit rule, and the Karnataka demo rule as potential matches. The exact display depends on the selected form values.

## Project architecture
- `app.py`: Flask routes and API validation
- `eligibility.py`: rule-matching engine
- `database.py`: SQLite setup and assessment history
- `schemes.json`: editable scheme catalogue and criteria
- `templates/index.html`: page structure
- `static/css/style.css`: responsive styling
- `static/js/app.js`: form submission, results and history rendering

## How to add or update a scheme
Add an object to `schemes.json`. Supported criteria:
- `categories`: e.g. `["OBC", "SC"]`; empty list means any category
- `states`: e.g. `["Karnataka"]`; `["ALL"]` means all states
- `education_levels`: `school`, `ug`, `pg`
- `max_income`: maximum configured annual family income
- `min_marks`: minimum percentage
- `min_age`, `max_age`
- `genders`: optional allowed values, e.g. `["Female"]`
- `disability_required`: optional boolean

Restart Flask after editing the JSON file.

## Sample API
`POST /api/check` accepts JSON with the student fields and returns an assessment ID, match count, matched criteria and conditions to review.

## Important academic and legal limitations
The bundled `schemes.json` contains demonstration criteria, not authoritative current government rules. Some entries are explicitly illustrative. Real eligibility may depend on domicile, institution approval, course type, admission year, family income certificate, caste certificate, previous marks, renewal status, gender, disability, deadlines and other conditions. Do not use this demo to make official eligibility claims. Replace each demo record only after checking the current official notification and record its source and last-verified date.

This prototype stores names and profile attributes in a local SQLite database. For a real public deployment, add authentication, HTTPS, consent, data minimisation, encryption, access controls, retention/deletion policy, CSRF protection, rate limiting and production hosting configuration. Do not collect Aadhaar numbers, bank details or document uploads in this classroom demo.

## Suggested future improvements
- Admin page to manage scheme records
- Upload and parse official scheme notifications
- Scheme source, last-verified date and application deadline fields
- State / central department filters
- Unit tests for eligibility rules
- Login and secure student dashboard
- Multilingual interface
