import sqlite3
import json
from pathlib import Path
from datetime import datetime

DB_PATH = Path(__file__).parent / "scholarship_data.db"

def connect():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with connect() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS assessments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                created_at TEXT NOT NULL,
                student_name TEXT NOT NULL,
                state TEXT NOT NULL,
                category TEXT NOT NULL,
                annual_income REAL NOT NULL,
                education_level TEXT NOT NULL,
                match_count INTEGER NOT NULL,
                results_json TEXT NOT NULL
            )
        """)

def save_assessment(student, results):
    with connect() as conn:
        cur = conn.execute("""
            INSERT INTO assessments
            (created_at, student_name, state, category, annual_income,
             education_level, match_count, results_json)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            datetime.now().isoformat(timespec="seconds"),
            student["name"], student["state"], student["category"],
            student["annual_income"], student["education_level"],
            len([r for r in results if r["status"] == "Potential match"]),
            json.dumps(results)
        ))
        return cur.lastrowid

def get_recent_assessments(limit=10):
    with connect() as conn:
        rows = conn.execute("""
            SELECT id, created_at, student_name, state, category,
                   education_level, match_count
            FROM assessments ORDER BY id DESC LIMIT ?
        """, (limit,)).fetchall()
        return [dict(row) for row in rows]
