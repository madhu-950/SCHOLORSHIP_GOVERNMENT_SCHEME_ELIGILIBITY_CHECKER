import json
from pathlib import Path

DATA_FILE = Path(__file__).parent / "schemes.json"

def load_schemes():
    with DATA_FILE.open(encoding="utf-8") as f:
        return json.load(f)

def evaluate_schemes(student, schemes):
    """Transparent rule-based matching. Returns matched and near-match schemes."""
    results = []
    for scheme in schemes:
        reasons, failed = [], []
        rule = scheme["criteria"]

        if rule.get("categories") and student["category"] not in rule["categories"]:
            failed.append("Category does not match")
        else:
            reasons.append("Category condition satisfied")

        states = rule.get("states", [])
        if states and "ALL" not in states and student["state"].lower() not in [s.lower() for s in states]:
            failed.append("State is outside the scheme's configured coverage")
        else:
            reasons.append("State coverage condition satisfied")

        levels = rule.get("education_levels", [])
        if levels and student["education_level"] not in levels:
            failed.append("Education level does not match")
        else:
            reasons.append("Education level condition satisfied")

        if student["annual_income"] > rule.get("max_income", float("inf")):
            failed.append(f"Annual family income exceeds configured limit of ₹{rule['max_income']:,}")
        else:
            reasons.append("Income condition satisfied")

        if student["marks"] < rule.get("min_marks", 0):
            failed.append(f"Marks are below configured minimum of {rule['min_marks']}%")
        else:
            reasons.append("Marks condition satisfied")

        genders = rule.get("genders", [])
        if genders and student["gender"] not in genders:
            failed.append("Gender condition does not match")
        else:
            if genders:
                reasons.append("Gender condition satisfied")

        min_age = rule.get("min_age", 0)
        max_age = rule.get("max_age", 120)
        if not min_age <= student["age"] <= max_age:
            failed.append(f"Age must be between {min_age} and {max_age}")
        else:
            reasons.append("Age condition satisfied")

        if rule.get("disability_required") and not student["disability"]:
            failed.append("Disability condition is required")
        elif rule.get("disability_required"):
            reasons.append("Disability condition satisfied")

        if not failed:
            status = "Potential match"
        elif len(failed) <= 2:
            status = "Needs review"
        else:
            continue

        results.append({
            "id": scheme["id"],
            "name": scheme["name"],
            "provider": scheme["provider"],
            "description": scheme["description"],
            "benefit": scheme["benefit"],
            "official_url": scheme["official_url"],
            "status": status,
            "matched_conditions": reasons,
            "conditions_to_check": failed,
            "verification_note": scheme["verification_note"]
        })

    results.sort(key=lambda x: (x["status"] != "Potential match", x["name"]))
    return results
